---
name: mood-to-motion

description: Art-direct a three-colour cinematic website hero and its staged colour-reveal Reel. Use when a user wants an emotional brand palette, hero composition, image prompts, consistent phase A/B/C visuals, motion direction, or a short voiceover. Do not use for claims of guaranteed engagement or conversion.
---

# Mood to Motion — Website Art Direction Skill

Turn a brand, product, or image into a distinctive website hero and a three-stage colour reveal: **base sets atmosphere → secondary clarifies the mood → accent changes the story**.

## Start with the brief
Ask only for essential missing details: brand/product, intended audience or feeling, visual subject, and whether they want a design concept, prompts, a script, or implementation. If images are attached, inspect them and preserve requested composition. If the user gives broad freedom, propose a direction without an intake questionnaire.

## Design workflow
1. **Emotional direction.** Define the desired first impression in 2–3 adjectives and a one-sentence brand promise. Translate emotions into design choices as hypotheses, not scientifically guaranteed effects.
2. **Three roles, three colours.** Choose (A) dark or light base for atmosphere, (B) contrasting supporting colour for hierarchy/readability, and (C) a visually distinctive accent for focal points and motion. Supply evocative, speakable names, hex values, proportions (guideline 70/25/5, adapt for contrast), and intended jobs. Avoid reusing the same accent across a multi-brand series when variety is requested. Verify text/button contrast; avoid relying only on hue to encode meaning.
3. **Hero art direction.** Define one dominant subject, one dramatic camera angle, one type treatment, one strong CTA, navigation and spatial layering. Use strong hierarchy, not a cluttered collage. For hero art, describe atmospheric lighting, reflections, environment, crop, negative space, and subject masking. Use oversized display type **behind** the subject, with selected intersecting letters rendered as outlines **over** the subject (the inverted-mask/outlined-overlay treatment), preserving legibility.
4. **Phase continuity.** Design a master layout first. All phases must retain identical dimensions, crop, camera position, subject proportions, type, spacing and CTA placement.
   - **A — atmosphere:** base hue dominates. Accent hue absent everywhere (including lights, reflections, flares, logos, button glow).
   - **B — character:** base + secondary only. Improve legibility, dimensionality and balance. Accent still completely absent.
   - **C — story:** add accent in physically plausible highlights, reflections, restrained motion streaks, and CTA focus, **without moving or redrawing** the subject.
5. **Motion beat sheet.** Suggest 3–7-second variations per site: base → supporting hue → accent flare → brief hero hold. Specify where light originates, how it travels, which layers move, which stay locked, and how to avoid flashing and excess motion. Distinguish editable DOM/CSS animation from video-editing instructions.
6. **Short-form script.** Match the colour-reveal beat with short phrases that are easy to say. Template: “{Base name} and {Secondary name}. {Mood}. Add {Accent name}, and now {emotional payoff}.” Make payoff specific to the design; no repetitive filler. If requested, include a practical, non-clickbait CTA to try the workflow.
7. **Handoff.** Provide a ready-to-use image-generation prompt, explicit negative constraints, an optional Claude Code/Codex implementation brief, and a checklist for visual continuity and mobile legibility. State if output is conceptual rather than deployed or tested.

## Output contract
For a quick answer, output only what the user asked for. For a complete concept, use this compact order:
- Brand / desired feeling / core visual idea
- A/B/C palette with names, hexes and exact role
- Hero specification, typography, CTA and mask/outline logic
- Phase A/B/C image prompts (one shared locked-scene specification + phase-specific lighting changes)
- Motion beat sheet and 15–25-second Reel voiceover, if requested
- QA checklist: consistent camera/crop, no stray accent in A/B, readable text, accessible focus/contrast, no false claims

## Guardrails
- Treat emotions, virality, and engagement as creative hypotheses; never guarantee performance, conversions, or retention.
- When an existing image is provided, request an edit preserving geometry; warn that generative editing can still alter details, and use layered graphics or segmentation/masking for pixel-precise results.
- If the model cannot directly animate or build a page, provide implementable directions rather than claim completion.
- Do not invent real specifications, endorsements, prices, company relationships, or customer results.
- Ask permission before changing an existing brand mark or introducing a real brand logo.
- Respect the user's chosen medium: a still image, editable page, or animation are not interchangeable.

See `references/examples.md` for three worked examples and `references/creative-checklist.md` for QA and repeatability.
