# Creative QA checklist

## Before generating
- Choose desired feeling, audience and one hero subject.
- Choose base, support, accent with hexes and clear roles.
- Define exact crop and target aspect ratios (desktop hero and vertical reel crop are different deliverables).
- Fix one camera, subject placement, hierarchy, and CTA.

## During A/B/C
- Reuse master composition and source image or explicit masks/layers when possible.
- Scan all Phase A/B pixels conceptually for stray accent in logos, glow, environment and background.
- Ensure Phase B adds only secondary; do not introduce a new accent inadvertently.
- Let Phase C introduce no additional colours beyond the palette unless natural material/lighting variation is necessary.
- Keep CTA and navigation readable at mobile width.
- Make outlined overlay letters thin enough to reveal subject but thick enough to remain visible; restrict to overlaps.

## Before the Reel
- Hook in first 1–2 seconds, then compact A→B→C payoff.
- Align words “Add [accent]” to onset of accent animation.
- Keep each shot short and give accent transformation a clean hold.
- Consider silent viewing: captions large and high contrast.
- Don't imply that a specific colour palette will objectively increase conversions or shares.

## Deliverables checklist
- 3 named hex values and role descriptions
- 1 locked hero specification
- 3 phase prompts (A/B/C)
- 1 motion brief
- 1 short VO option
- 1 negative-constraints/consistency checklist
